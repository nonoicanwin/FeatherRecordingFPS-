# FeatherFPS Android source

Native Android/Kotlin starter project for FeatherFPS. Open the project root in Android Studio (JDK 17, Android SDK 35) and let Gradle sync.

## Included
- Animated FeatherFPS splash/intro with a custom drawn feather mark and glow.
- Dark dashboard and top-right three-line menu.
- Blue / purple / red / green accent themes.
- Resolution, frame-rate, bitrate, audio, orientation and countdown preference controls.
- Ipad Stretch settings area with 4:3 and custom percentage control.
- MediaProjection screen capture service with H.264 MP4 output and pause/resume service actions.
- Gallery handoff to the device's video gallery.

## Important implementation status
This is a source project foundation, not a fully finished production recorder. The current recorder engine intentionally uses the device's native display dimensions, 30 FPS, 8 Mbps and microphone-free video capture; the settings controls are UI scaffolding and are not all wired into MediaRecorder yet. Countdown, floating overlay controls, live in-app stats, custom bitrate/FPS/resolution application, audio capture, trim/crop editing and actual stretch/transcode export still need implementation and device testing.

Android screen capture requires the system MediaProjection consent prompt. Internal audio capture is only possible on supported Android versions and apps that permit playback capture; combining internal audio with microphone requires a dedicated AudioRecord/MediaCodec muxing pipeline. The app cannot change the phone's system display aspect ratio or force an iPad-like screen shape. The Ipad Stretch panel is currently a settings UI placeholder; applying stretch to saved videos requires a video-processing/export stage.

## Compatibility
- minSdk 26 (Android 8.0); Android 10+ recommended for modern MediaProjection behavior.
- targetSdk 35.
- Test on a real device. Some OEMs restrict background recording and overlays.
- No Gradle wrapper is included; Android Studio or an installed Gradle 8.9 can build it.

## Build
`gradle :app:assembleDebug`

The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.
