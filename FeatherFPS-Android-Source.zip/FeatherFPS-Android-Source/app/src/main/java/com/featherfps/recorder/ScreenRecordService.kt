package com.featherfps.recorder

import android.app.*
import android.content.Context
import android.content.Intent
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager
import java.io.File

class ScreenRecordService : Service() {
    companion object {
        const val ACTION_START = "com.featherfps.START"
        const val ACTION_STOP = "com.featherfps.STOP"
        const val ACTION_PAUSE = "com.featherfps.PAUSE"
        const val ACTION_RESUME = "com.featherfps.RESUME"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "projection_data"
        private const val CHANNEL = "feather_recording"
        private const val NOTIFICATION = 71
    }

    private var projection: MediaProjection? = null
    private var recorder: MediaRecorder? = null
    private var display: VirtualDisplay? = null
    private var output: File? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startRecording(intent)
            ACTION_PAUSE -> try { recorder?.pause(); notify("Paused • FeatherFPS") } catch (_: Exception) {}
            ACTION_RESUME -> try { recorder?.resume(); notify("Recording • FeatherFPS") } catch (_: Exception) {}
            ACTION_STOP -> stopRecording()
        }
        return START_NOT_STICKY
    }

    private fun startRecording(i: Intent) {
        createChannel()
        startForeground(NOTIFICATION, notification("Preparing recording…"))
        try {
            val resultCode = i.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
            @Suppress("DEPRECATION")
            val data = if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(EXTRA_DATA, Intent::class.java)
                       else i.getParcelableExtra(EXTRA_DATA)
            if (data == null) { stopSelf(); return }
            val pm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = pm.getMediaProjection(resultCode, data)

            val dm = DisplayMetrics()
            @Suppress("DEPRECATION")
            (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(dm)
            val width = dm.widthPixels
            val height = dm.heightPixels
            val density = dm.densityDpi

            val dir = getExternalFilesDir(android.os.Environment.DIRECTORY_MOVIES) ?: filesDir
            if (!dir.exists()) dir.mkdirs()
            output = File(dir, "FeatherFPS_${System.currentTimeMillis()}.mp4")

            @Suppress("DEPRECATION")
            val mr = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()
            recorder = mr
            mr.setVideoSource(MediaRecorder.VideoSource.SURFACE)
            mr.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            mr.setOutputFile(output!!.absolutePath)
            mr.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            mr.setVideoSize(width - (width % 2), height - (height % 2))
            mr.setVideoFrameRate(30)
            mr.setVideoEncodingBitRate(8_000_000)
            mr.prepare()
            display = projection!!.createVirtualDisplay(
                "FeatherFPS", width, height, density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                mr.surface, null, null
            )
            mr.start()
            notify("Recording • ${width}×${height} • 30 FPS")
        } catch (e: Exception) {
            stopRecording()
            android.util.Log.e("FeatherFPS", "Recorder failed", e)
        }
    }

    private fun stopRecording() {
        try { recorder?.stop() } catch (_: Exception) {}
        try { recorder?.reset(); recorder?.release() } catch (_: Exception) {}
        recorder = null
        try { display?.release() } catch (_: Exception) {}
        display = null
        try { projection?.stop() } catch (_: Exception) {}
        projection = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Screen recording", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun notification(text: String): Notification {
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)
        return builder.setContentTitle("FeatherFPS").setContentText(text)
            .setSmallIcon(android.R.drawable.presence_video_online)
            .setOngoing(true).build()
    }
    private fun notify(text: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION, notification(text))
    }

    override fun onDestroy() { stopRecording(); super.onDestroy() }
}
