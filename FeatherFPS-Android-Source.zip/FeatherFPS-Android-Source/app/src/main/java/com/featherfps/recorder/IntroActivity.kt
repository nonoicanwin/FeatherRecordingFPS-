package com.featherfps.recorder

import android.app.Activity
import android.content.Intent
import android.graphics.*
import android.os.Bundle
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.TextView

class IntroActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = FrameLayout(this).apply { setBackgroundColor(Color.rgb(5, 10, 22)) }
        val logo = FeatherMark(this)
        root.addView(logo, FrameLayout.LayoutParams(230, 230).apply {
            gravity = android.view.Gravity.CENTER
        })
        val title = TextView(this).apply {
            text = "FEATHER FPS\nCAPTURE EVERYTHING"
            textSize = 22f
            gravity = android.view.Gravity.CENTER
            setTextColor(Color.WHITE)
            letterSpacing = .16f
        }
        root.addView(title, FrameLayout.LayoutParams(-1, 100).apply {
            gravity = android.view.Gravity.CENTER
            topMargin = 260
        })
        setContentView(root)
        logo.alpha = 0f
        logo.scaleX = .55f
        logo.scaleY = .55f
        logo.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(1200)
            .setInterpolator(DecelerateInterpolator()).start()
        title.alpha = 0f
        title.animate().alpha(1f).setStartDelay(950).setDuration(800).start()
        root.postDelayed({
            startActivity(Intent(this, MainActivity::class.java).putExtra("skip_intro", true))
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            finish()
        }, 2600)
    }

    private class FeatherMark(context: android.content.Context) : View(context) {
        private val paint = Paint(3)
        private val glow = Paint(3)
        private var phase = 0f
        private val p = Path()
        override fun onDraw(c: Canvas) {
            super.onDraw(c)
            val cx = width / 2f
            val cy = height / 2f
            val r = minOf(width, height) * .34f
            c.save()
            c.rotate(phase, cx, cy)
            glow.color = Color.rgb(0, 155, 255)
            glow.style = Paint.Style.STROKE
            glow.strokeWidth = 13f
            glow.maskFilter = BlurMaskFilter(22f, BlurMaskFilter.Blur.NORMAL)
            c.drawCircle(cx, cy, r, glow)
            paint.shader = LinearGradient(cx-r, cy-r, cx+r, cy+r,
                intArrayOf(Color.rgb(110,225,255), Color.rgb(15,105,220), Color.WHITE),
                null, Shader.TileMode.CLAMP)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 9f
            paint.strokeCap = Paint.Cap.ROUND
            p.reset()
            p.moveTo(cx-r*.62f, cy+r*.75f)
            p.cubicTo(cx-r*.15f, cy+r*.1f, cx+r*.05f, cy-r*.55f, cx+r*.72f, cy-r*.8f)
            p.cubicTo(cx+r*.38f, cy-r*.1f, cx+r*.25f, cy+r*.35f, cx-r*.62f, cy+r*.75f)
            c.drawPath(p, paint)
            paint.shader = null
            paint.color = Color.WHITE
            paint.strokeWidth = 3f
            c.drawLine(cx-r*.35f, cy+r*.52f, cx+r*.53f, cy-r*.58f, paint)
            c.restore()
            phase += 1.2f
            if (phase >= 360f) phase = 0f
            postInvalidateDelayed(32)
        }
    }
}
