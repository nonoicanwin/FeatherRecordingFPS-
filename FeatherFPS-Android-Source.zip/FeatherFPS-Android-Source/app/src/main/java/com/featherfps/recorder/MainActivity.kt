package com.featherfps.recorder

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable

class MainActivity : Activity() {
    private val requestCapture = 4101
    private val requestAudio = 4102
    private lateinit var status: TextView
    private lateinit var root: LinearLayout
    private var accent = Color.rgb(48, 170, 255)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null && !intent.getBooleanExtra("skip_intro", false)) {
            startActivity(Intent(this, IntroActivity::class.java))
            finish()
            return
        }
        accent = themeColor(Prefs.get(this, "theme", "Blue"))
        buildUi()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 28, 22, 32)
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(5, 10, 22), Color.rgb(12, 22, 42)))
        }
        scroll.addView(root)
        setContentView(scroll)

        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val brand = TextView(this).apply {
            text = "FEATHERFPS"
            textSize = 24f
            letterSpacing = .12f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
        }
        header.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        val menu = TextView(this).apply {
            text = "☰"
            textSize = 30f
            setTextColor(Color.WHITE)
            setPadding(18, 4, 8, 8)
            setOnClickListener { showMenu() }
        }
        header.addView(menu)
        root.addView(header)

        val sub = label("YOUR POCKET RECORDING STUDIO")
        sub.textSize = 10f
        sub.setTextColor(accent)
        root.addView(sub)
        root.addView(space(18))

        val hero = card()
        hero.orientation = LinearLayout.VERTICAL
        hero.addView(label("READY TO CAPTURE?").apply { textSize = 13f; setTextColor(accent) })
        status = label("Screen recorder is idle")
        status.textSize = 18f
        hero.addView(status)
        val start = button("●   START RECORDING")
        start.setOnClickListener { beginCapture() }
        hero.addView(start)
        root.addView(hero)
        root.addView(space(14))

        section("RECORDING SETTINGS")
        val quality = row()
        quality.addView(spinner("Resolution", listOf("480p","720p","1080p","1440p"), "1080p"), weight())
        quality.addView(spinner("Frame rate", listOf("24 FPS","30 FPS","60 FPS","90 FPS","120 FPS"), "60 FPS"), weight())
        root.addView(quality)
        root.addView(spinner("Audio source", listOf("Microphone","Internal audio (Android 10+, app support required)","Internal + microphone (device/app support required)"), "Microphone"))
        root.addView(spinner("Orientation", listOf("Auto","Portrait","Landscape"), "Auto"))
        root.addView(spinner("Countdown", listOf("3 seconds","5 seconds","10 seconds","Off"), "3 seconds"))
        root.addView(spinner("Bitrate", listOf("2 Mbps","4 Mbps","6 Mbps","8 Mbps","12 Mbps","16 Mbps","Custom (6 Mbps)"), "8 Mbps"))

        section("IPAD STRETCH")
        val stretchCard = card().apply { orientation = LinearLayout.VERTICAL }
        stretchCard.addView(label("OUTPUT SHAPE").apply { setTextColor(accent) })
        val ratioControl = spinner("Aspect ratio", listOf("Original","4:3","16:9","1:1"), "Original")
        stretchCard.addView(ratioControl)
        val stretchLabel = label("Custom stretch percentage: 100%")
        stretchCard.addView(stretchLabel)
        val seek = SeekBar(this).apply {
            max = 200
            progress = 100
            progressTintList = android.content.res.ColorStateList.valueOf(accent)
            thumbTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
        }
        stretchCard.addView(seek)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, v: Int, user: Boolean) {
                stretchLabel.text = "Custom stretch percentage: ${v.coerceAtLeast(1)}%"
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        stretchCard.addView(label("Stretch controls are saved as output preferences. Applying a transformed export requires the video-processing stage."))
        root.addView(stretchCard)

        section("LIVE SESSION")
        val controls = row()
        controls.addView(button("Ⅱ  PAUSE").apply { setOnClickListener { sendAction(ScreenRecordService.ACTION_PAUSE) } }, weight())
        controls.addView(button("▶  RESUME").apply { setOnClickListener { sendAction(ScreenRecordService.ACTION_RESUME) } }, weight())
        controls.addView(button("■  STOP").apply { setOnClickListener { sendAction(ScreenRecordService.ACTION_STOP); status.text = "Stopping recording…" } }, weight())
        root.addView(controls)
        root.addView(button("OPEN RECORDING GALLERY").apply { setOnClickListener { openGallery() } })
        root.addView(button("THEMES & APP MENU").apply { setOnClickListener { showMenu() } })
        root.addView(space(12))
        root.addView(label("Live stats are shown in the ongoing recording notification."))
    }

    private fun beginCapture() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), requestAudio)
            return
        }
        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mgr.createScreenCaptureIntent(), requestCapture)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestCapture && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, ScreenRecordService::class.java).apply {
                action = ScreenRecordService.ACTION_START
                putExtra(ScreenRecordService.EXTRA_RESULT_CODE, resultCode)
                putExtra(ScreenRecordService.EXTRA_DATA, data)
            }
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
            status.text = "Recording • check notification for controls"
        }
    }

    private fun sendAction(action: String) {
        startService(Intent(this, ScreenRecordService::class.java).setAction(action))
    }

    private fun openGallery() {
        val i = Intent(Intent.ACTION_VIEW).apply { type = "video/*"; setDataAndType(Uri.parse("content://media/external/video/media"), "video/*") }
        try { startActivity(i) } catch (_: Exception) { Toast.makeText(this, "No gallery app found", Toast.LENGTH_SHORT).show() }
    }

    private fun showMenu() {
        val options = arrayOf("Blue theme","Purple theme","Red theme","Green theme","About FeatherFPS")
        AlertDialog.Builder(this).setTitle("FeatherFPS menu").setItems(options) { _, which ->
            if (which < 4) {
                val names = listOf("Blue","Purple","Red","Green")
                Prefs.put(this, "theme", names[which])
                accent = themeColor(names[which])
                buildUi()
            } else AlertDialog.Builder(this).setMessage("FeatherFPS • Android screen recorder").setPositiveButton("OK", null).show()
        }.show()
    }

    private fun spinner(title: String, values: List<String>, selected: String): LinearLayout {
        val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 5, 8, 5) }
        wrap.addView(label(title).apply { textSize = 12f; setTextColor(Color.LTGRAY) })
        val sp = Spinner(this)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, values)
        sp.setSelection(values.indexOf(selected).coerceAtLeast(0))
        wrap.addView(sp)
        return wrap
    }

    private fun label(s: String) = TextView(this).apply { text = s; textSize = 15f; setTextColor(Color.WHITE); setPadding(0, 6, 0, 6) }
    private fun section(s: String) { root.addView(space(15)); root.addView(label(s).apply { textSize = 13f; setTextColor(accent); typeface = Typeface.DEFAULT_BOLD }) }
    private fun card() = LinearLayout(this).apply {
        setPadding(16, 16, 16, 16)
        background = GradientDrawable().apply { setColor(Color.rgb(17, 30, 51)); cornerRadius = 22f; setStroke(1, Color.rgb(36, 75, 110)) }
    }
    private fun button(s: String) = TextView(this).apply {
        text = s; gravity = Gravity.CENTER; textSize = 13f; typeface = Typeface.DEFAULT_BOLD
        setTextColor(Color.WHITE); setPadding(14, 16, 14, 16)
        background = GradientDrawable().apply { setColor(Color.rgb(19, 75, 125)); cornerRadius = 16f }
        isClickable = true
    }
    private fun row() = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
    private fun weight() = LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(3, 3, 3, 3) }
    private fun space(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, h) }
    private fun themeColor(name: String) = when (name) {
        "Purple" -> Color.rgb(177, 112, 255)
        "Red" -> Color.rgb(255, 85, 105)
        "Green" -> Color.rgb(72, 220, 155)
        else -> Color.rgb(48, 170, 255)
    }
}
