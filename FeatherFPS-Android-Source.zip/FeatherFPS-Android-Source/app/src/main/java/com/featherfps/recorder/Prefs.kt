package com.featherfps.recorder

import android.content.Context

object Prefs {
    private const val FILE = "feather_settings"
    private fun p(c: Context) = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun get(c: Context, key: String, fallback: String) = p(c).getString(key, fallback) ?: fallback
    fun put(c: Context, key: String, value: String) = p(c).edit().putString(key, value).apply()
    fun int(c: Context, key: String, fallback: Int) = p(c).getInt(key, fallback)
    fun putInt(c: Context, key: String, value: Int) = p(c).edit().putInt(key, value).apply()
}
